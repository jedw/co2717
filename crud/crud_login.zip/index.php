<!DOCTYPE html>
<html>
    <head>
        <title>CRUD</title>
    </head>
    <body>
        <?php include 'nav.php'?>
    </body>
</html>