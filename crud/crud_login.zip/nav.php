<a href="display.php">Display Records </a>
<a href="newuser2.php">Add New Record </a>
<a href="login.php">Login </a>